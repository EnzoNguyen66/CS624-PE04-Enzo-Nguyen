### CS624

### HOS05


Please follow the instructions on the [CityU STC Student Resource Center Github.io page](https://cityuseattle.github.io/) to set up your computer for completing HOS assignments. 

1. Before starting this assignment, you should have followed the instructions under the Git section to Install Git, Create a GitHub Account, and Install GitHub Desktop (optional). If you missed any of these sections, please check the guide [here](https://cityuseattle.github.io/docs/git).

2. It is important to store your HOS assignments in a location you will remember and that make sense to you. For our recommendation, check the [Organize HOS page](https://cityuseattle.github.io/docs/hoporhos/organization/).

3. Once you have a place to store your work, you will need to clone this repository. For instructions on how to do so, check the Clone or Download section on the [Guide HOS page](https://cityuseattle.github.io/docs/hoporhos/guide/).

4. You should see some word document(s) or pdf file(s) inside the repository. Follow the instructions and complete your work. 

<strong>SUBMIT YOUR WORK </strong>

Once you have completed the assignment, you will need to push your work to GitHub.

Follow the instructions on the [Submit your work page](https://cityuseattle.github.io/docs/git/codespaces_submission/) to do so.
